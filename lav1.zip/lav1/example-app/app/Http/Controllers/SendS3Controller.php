<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\Storage;
use Illuminate\Http\Request;

class SendS3Controller extends Controller
{
    public function sending(Request $request)
    {

        // Capturamos el archivo
        $archivo = $request->file('archivo');

        // Subimos el archivo a la carpeta 'enero/' en S3 y generamos nombre único
        $ruta = $archivo->store('enero', 's3');

        $url = Storage::disk('s3')->put('enero/', $ruta);
        dd($url);
        return response()->json(['url' => $url]);
    }
}
