<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <title>Subir archivo a S3</title>
</head>

<body>
    <h1>Subir archivo a S3</h1>

    <?php if(session('mensaje')): ?>
    <p style="color: green;"><?php echo e(session('mensaje')); ?></p>
    <?php endif; ?>

    <form action="<?php echo e(route('sending.archivo')); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <label for="archivo">Seleccione un archivo:</label><br>
        <input type="file" name="archivo" required><br><br>

        <button type="submit">Subir a S3</button>
    </form>
</body>

</html><?php /**PATH C:\Users\SENA\Documents\frontendYusef7332025\lav1\example-app\resources\views/subir.blade.php ENDPATH**/ ?>